Bienvenido al Taller de Bash
Este es un archivo README de ejemplo
sáb 01 feb 2025 21:09:10 CET
