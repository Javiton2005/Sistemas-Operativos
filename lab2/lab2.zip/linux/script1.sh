#!/bin/bash
readd -r Input
echo "Este es el Script 1. $Input"
