#!/bin/bash
./script1.sh
./script2.sh
echo "Ambos scripts se han ejecutado."
