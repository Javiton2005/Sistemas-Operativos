#! /bin/bash

path=$(pwd)
echo $pathfile

echo "export PATH=\$PATH:$path" >> ~/.bashrc

