#!/bin/bash
0 10 * * * /ruta/al/script.sh
