#!/bin/bash
mkdir -p BatchWorkshop
echo "Bienvenido al Taller de Bash" > BatchWorkshop/README.txt
echo "Este es un archivo README de ejemplo" >> BatchWorkshop/README.txt
cat ./BatchWorkshop/README.txt
