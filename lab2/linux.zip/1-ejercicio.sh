#!/bin/bash
echo "Fecha y hora actual:"
date
