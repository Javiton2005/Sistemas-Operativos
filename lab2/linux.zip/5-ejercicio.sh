#!/bin/bash
gedit &
echo "El editor de texto se ha abierto."
