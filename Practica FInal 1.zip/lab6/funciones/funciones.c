#include "funciones.h"

char *funcionesMenu[] = {
    "Sacar Dinero",            //
    "Meter Dinero",            //
    "Consultar Saldo",         // Javier
    "Informacion de la Cuenta",// Javier
    "Transaccion",             // Panch
    "Pagar Tasas",             // Panch
    "Cancelar Tarjetas",       // 
    "Salir/Cerrar",            // Javier
    NULL
};
