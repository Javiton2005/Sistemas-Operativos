#ifndef LOGIN_H
  #define LOGIN_H

#include "../comun/comun.h"
#include "../funciones/funciones.h"

void login(USER **listaUsuarios);

#endif // LOGIN_H
